import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]';
import pool from '@/lib/db';
import { UserType, ProjectStatus } from '@/types';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  
  if (!session) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  if (session.user.userType !== UserType.ADMIN) {
    return res.status(403).json({ message: 'Access denied' });
  }
  
  const { id } = req.query;
  
  if (!id || isNaN(Number(id))) {
    return res.status(400).json({ message: 'Invalid project ID' });
  }
  
  const projectId = parseInt(id as string);
  
  switch (req.method) {
    case 'PATCH':
      return await updateProject(req, res, projectId);
    default:
      return res.status(405).json({ message: 'Method not allowed' });
  }
}

async function updateProject(req: NextApiRequest, res: NextApiResponse, projectId: number) {
  try {
    const { action } = req.body;
    
    if (!action) {
      return res.status(400).json({ message: 'Action is required' });
    }
    
    const client = await pool.connect();
    
    try {
      await client.query('BEGIN');
      
      // Check if project exists
      const projectResult = await client.query(
        'SELECT * FROM projects WHERE id = $1',
        [projectId]
      );
      
      if (projectResult.rows.length === 0) {
        return res.status(404).json({ message: 'Project not found' });
      }
      
      let result;
      
      switch (action) {
        case 'approve':
          result = await client.query(
            'UPDATE projects SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *',
            [ProjectStatus.APPROVED, projectId]
          );
          
          // Add activity log
          await client.query(
            `INSERT INTO activity_log (
              type, 
              title, 
              description, 
              metadata
            ) VALUES ($1, $2, $3, $4)`,
            [
              'project_approval',
              'Project Approved',
              `Project "${result.rows[0].title}" has been approved`,
              JSON.stringify({
                projectId,
                projectTitle: result.rows[0].title,
              })
            ]
          );
          break;
          
        case 'reject':
          result = await client.query(
            'UPDATE projects SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *',
            [ProjectStatus.REJECTED, projectId]
          );
          break;
          
        case 'feature':
          // Toggle featured status
          result = await client.query(
            'UPDATE projects SET is_featured = NOT is_featured, updated_at = NOW() WHERE id = $1 RETURNING *',
            [projectId]
          );
          break;
          
        default:
          return res.status(400).json({ message: 'Invalid action' });
      }
      
      await client.query('COMMIT');
      
      return res.status(200).json({
        id: result.rows[0].id,
        status: result.rows[0].status,
        isFeatured: result.rows[0].is_featured
      });
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  } catch (error) {
    console.error('Error updating project:', error);
    return res.status(500).json({ message: 'Error updating project' });
  }
}