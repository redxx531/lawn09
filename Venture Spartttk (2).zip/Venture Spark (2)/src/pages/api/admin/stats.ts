import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../auth/[...nextauth]';
import pool from '@/lib/db';
import { UserType } from '@/types';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  
  if (!session) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  if (session.user.userType !== UserType.ADMIN) {
    return res.status(403).json({ message: 'Access denied' });
  }
  
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method not allowed' });
  }
  
  try {
    // Execute queries in parallel
    const [
      totalUsersResult,
      totalProjectsResult,
      totalInvestmentsResult,
      totalAmountResult,
      pendingProjectsResult
    ] = await Promise.all([
      pool.query('SELECT COUNT(*) FROM users'),
      pool.query('SELECT COUNT(*) FROM projects'),
      pool.query('SELECT COUNT(*) FROM investments'),
      pool.query('SELECT COALESCE(SUM(amount), 0) as total FROM investments'),
      pool.query('SELECT COUNT(*) FROM projects WHERE status = $1', ['pending'])
    ]);
    
    const stats = {
      totalUsers: parseInt(totalUsersResult.rows[0].count),
      totalProjects: parseInt(totalProjectsResult.rows[0].count),
      totalInvestments: parseInt(totalInvestmentsResult.rows[0].count),
      totalAmountInvested: parseFloat(totalAmountResult.rows[0].total),
      pendingProjects: parseInt(pendingProjectsResult.rows[0].count)
    };
    
    return res.status(200).json(stats);
  } catch (error) {
    console.error('Error fetching admin stats:', error);
    return res.status(500).json({ message: 'Error fetching admin statistics' });
  }
}