import { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]';
import pool from '@/lib/db';
import { UserType } from '@/types';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const session = await getServerSession(req, res, authOptions);
  
  if (!session) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
  
  if (session.user.userType !== UserType.ADMIN) {
    return res.status(403).json({ message: 'Access denied' });
  }
  
  const { id } = req.query;
  
  if (!id || isNaN(Number(id))) {
    return res.status(400).json({ message: 'Invalid page ID' });
  }
  
  const pageId = parseInt(id as string);
  
  switch (req.method) {
    case 'GET':
      return await getPageById(req, res, pageId);
    case 'PUT':
      return await updatePage(req, res, pageId);
    case 'PATCH':
      return await updatePageStatus(req, res, pageId);
    case 'DELETE':
      return await deletePage(req, res, pageId);
    default:
      return res.status(405).json({ message: 'Method not allowed' });
  }
}

async function getPageById(req: NextApiRequest, res: NextApiResponse, id: number) {
  try {
    const query = `
      SELECT 
        id, 
        slug, 
        title, 
        content,
        meta_description, 
        is_published, 
        created_at,
        updated_at
      FROM pages
      WHERE id = $1
    `;
    
    const result = await pool.query(query, [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Page not found' });
    }
    
    return res.status(200).json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching page:', error);
    return res.status(500).json({ message: 'Error fetching page' });
  }
}

async function updatePage(req: NextApiRequest, res: NextApiResponse, id: number) {
  try {
    const { title, slug, content, meta_description, is_published } = req.body;
    
    if (!title || !slug || !content) {
      return res.status(400).json({ message: 'Title, slug, and content are required' });
    }
    
    // Check if slug already exists for another page
    const checkQuery = `
      SELECT id FROM pages WHERE slug = $1 AND id != $2
    `;
    
    const checkResult = await pool.query(checkQuery, [slug, id]);
    
    if (checkResult.rows.length > 0) {
      return res.status(400).json({ message: 'Another page with this slug already exists' });
    }
    
    const query = `
      UPDATE pages 
      SET 
        slug = $1,
        title = $2,
        content = $3,
        meta_description = $4,
        is_published = $5,
        updated_at = NOW()
      WHERE id = $6
      RETURNING id
    `;
    
    const result = await pool.query(query, [
      slug,
      title,
      content,
      meta_description || '',
      is_published,
      id
    ]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Page not found' });
    }
    
    return res.status(200).json({
      message: 'Page updated successfully'
    });
  } catch (error) {
    console.error('Error updating page:', error);
    return res.status(500).json({ message: 'Error updating page' });
  }
}

async function updatePageStatus(req: NextApiRequest, res: NextApiResponse, id: number) {
  try {
    const { is_published } = req.body;
    
    if (is_published === undefined) {
      return res.status(400).json({ message: 'is_published field is required' });
    }
    
    const query = `
      UPDATE pages 
      SET 
        is_published = $1,
        updated_at = NOW()
      WHERE id = $2
      RETURNING id
    `;
    
    const result = await pool.query(query, [is_published, id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Page not found' });
    }
    
    return res.status(200).json({
      message: `Page ${is_published ? 'published' : 'unpublished'} successfully`
    });
  } catch (error) {
    console.error('Error updating page status:', error);
    return res.status(500).json({ message: 'Error updating page status' });
  }
}

async function deletePage(req: NextApiRequest, res: NextApiResponse, id: number) {
  try {
    const query = `
      DELETE FROM pages
      WHERE id = $1
      RETURNING id
    `;
    
    const result = await pool.query(query, [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Page not found' });
    }
    
    return res.status(200).json({
      message: 'Page deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting page:', error);
    return res.status(500).json({ message: 'Error deleting page' });
  }
}