import { NextApiRequest, NextApiResponse } from 'next';
import pool from '@/lib/db';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { slug } = req.query;
  
  if (!slug || typeof slug !== 'string') {
    return res.status(400).json({ message: 'Invalid blog post slug' });
  }
  
  try {
    // Get blog post
    const postQuery = `
      SELECT 
        b.id, 
        b.title, 
        b.slug, 
        b.content, 
        b.featured_image_url, 
        b.created_at,
        b.updated_at,
        b.author_id,
        u.name as author_name
      FROM blog_posts b
      LEFT JOIN users u ON b.author_id = u.id
      WHERE b.slug = $1 AND b.is_published = true
    `;
    
    const postResult = await pool.query(postQuery, [slug]);
    
    if (postResult.rows.length === 0) {
      return res.status(404).json({ message: 'Blog post not found' });
    }
    
    const post = postResult.rows[0];
    
    // Get related posts
    const relatedQuery = `
      SELECT 
        id, 
        title, 
        slug, 
        featured_image_url
      FROM blog_posts
      WHERE is_published = true AND id != $1
      ORDER BY created_at DESC
      LIMIT 3
    `;
    
    const relatedResult = await pool.query(relatedQuery, [post.id]);
    const relatedPosts = relatedResult.rows;
    
    return res.status(200).json({
      post,
      relatedPosts
    });
  } catch (error) {
    console.error('Error fetching blog post:', error);
    return res.status(500).json({ message: 'Error fetching blog post' });
  }
}